class Onenex < Formula
  desc "Command-line interface install starter kits from github.com/onenex"
  homepage "https://github.com/onenex"
  url "https://github.com/onenex/onenex/archive/v1.0.0.tar.gz"
  sha256 "INSERT SHA256 HASH HERE"

  def install
    bin.install "onenex"
  end
end
